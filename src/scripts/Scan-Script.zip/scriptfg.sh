#!/bin/bash

green="\e[0;32m\033[1m"
end="\033[0m\e[0m"
red="\e[0;31m\033[1m"
blue="\e[0;34m\033[1m"
yellow="\e[0;33m\033[1m"
purple="\e[0;35m\033[1m"
turquoise="\e[0;36m\033[1m"
gray="\e[0;37m\033[1m"

trap ctrl_c INT

function ctrl_c(){
	echo -e "\n${red}[*]${yellow} Saliendo..."
	exit 0
}

function dependencias(){
if [ "$(id -u)" == 0 ];then
	if [ -f /usr/bin/nmap ];then
		echo -e "${green}[V] Nmap instalado"
	else
		echo -e "${red}[!]${blue} Nmap${yellow} no está instalado. "
		echo -e "${turquoise} Instalando nmap... ${purple}"
		sudo apt-get install nmap -y
		echo -e "${green}[V] Nmap instalado correctamente"
	fi

	if [ -f /usr/bin/nikto ];then
		echo -e "${green}[V] Nikto instalado"
     else
         echo -e "${red}[!] ${yellow}Nikto no está instalado. "
         echo -e "${turquoise} Instalando nikto... ${purple}"
         sudo apt-get install nikto -y
         echo -e "${green}[V] Nikto instalado correctamente"
     fi
   	if [ -d logs/ ]; then
             echo ""
     else
            mkdir logs
			mkdir logs/nikto
			mkdir logs/nmap
			echo -e "${green}[V] Carpeta de logs creada\n"
     fi

	if [ -f /usr/bin/speedtest-cli ];then
		echo -e "${green}[V] Speedtest-cli instalado"
	else
		echo -e "${red}[!]${yellow} Speedtest-cli no está instalado!"
		echo -e "${red} [·] Instalando speedtest-cli..."
		sudo apt-get install speedtest-cli -y
	fi
else
	echo -e "${red}[!]${yellow} No has iniciado como root!"
fi

}

function nmapScan(){
	if [ "$(id -u)" == 0 ];then
		dependencias
		clear
		tput civis
		echo -e "${blue}--NMAP MENU--"
		echo -e "${turquoise}1)${red} Escaneo de puertos silencioso"
		echo -e "${turquoise}2)${red} Escaneo de puertos agresivo ${end}\n"
		tput cnorm
        read -p "Escribe el número de la opción que deseas: " -r option
		read -p "Output (Enter para no guardar log): " -r output
		echo -e "\n\n"
		tput civis
		if [ "$(echo $option)" == 1 ];then
				echo -e "${blue}--- ESCANEANDO $ip SILENCIOSAMENTE --- \n ${green}"
				if [ "$(echo $output)" == "" ];then
					nmap -sT -P0 $ip -vvv
				else
 	    		    nmap -sT -P0 $ip -vvv -o logs/nmap/$output.txt
					echo -e "\n${blue} RESULTADO ALMACENADO EN logs/$output.txt ${end}"
		            tput cnorm
				fi
         elif [ "$(echo $option)" == 2 ];then
				echo -e "${blue}--- ESCANEANDO $ip AGRESIVAMENTE --- \n ${green}"
				if [ "$(echo $output)" == "" ];then
					nmap -A $ip
					tput cnorm
				else
                	nmap -A $ip -o logs/nmap/$output.txt
					echo -e "\n${blue} RESULTADO ALMACENADO EN logs/$output.txt ${end}"
                	tput cnorm
				fi
         else
              echo -e "${red}[!]${yellow} Debes introducir una opción válida!"
          fi
	else
		echo -e "${red}[!]${yellow} No has iniciado como root!"
	fi
}

function niktoScan(){
	dependencias
	if [ "$(id -u)" == 0 ];then
		read -p "Output (Enter para no guardar log): " -r output
		if [ "$(echo $output)" == "" ];then
			nikto -h $ip
		else
			nikto -h $ip -o logs/nikto/$output.txt
		fi
	else
		echo -e "${red}[!]${yellow} No has iniciado como root!"
	fi
}

function borrado(){
	if [ "$(id -u)" == 0 ];then
		sudo rm -r logs 2>/dev/null
		echo -e "${green}[V] ${yellow} Carpeta de logs eliminada"
		sudo apt-get remove speedtest-cli -y &>/dev/null
		echo -e "${green}[V] ${yellow} Speedtest-cli desinstalado"
	else
		echo -e "${red}[!]${yellow} No has iniciado como root!"
	fi
}

function helpPanel(){
	echo -e "${blue}[-- PANEL DE AYUDA --]"
	echo -e "${purple}USO: ./scan-script.sh -x [dirección ip]"
	echo -e "${purple}-n [ip]${green}\t Nmap"
	echo -e "${purple}-k [ip]${green}\t Nikto"
	echo -e "${purple}-p [ip]${green}\t Ping test"
	echo -e "${purple}-t ${green}\t Test de conexión"
	echo -e "${purple}-i ${green}\t Instalar dependencias ${gray}(Nmap, Nikto)${end}"
	echo -e "${purple}-b ${green}\t Borrar logs"
}

declare -i counter=0;while getopts "n:p:k:tibh" arg; do
        case $arg in
            n) ip=$OPTARG; nmapScan; counter+=1;;
			p) ping -c 1 $OPTARG; counter+=1;;
			k) ip=$OPTARG; niktoScan; counter+=1;;
			t) dependencias; speedtest-cli; counter+=1;;
			i) dependencias; counter+=1;;
			h) helpPanel; counter+=1;;
			b) borrado; counter+=1;;
        esac
    if [ $counter == 0 ];then
        helpPanel
    else
        exit 0
    fi
done
