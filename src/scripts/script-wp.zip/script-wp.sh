#!/bin/bash


#Colours
green="\e[0;32m\033[1m"
end="\033[0m\e[0m"
red="\e[0;31m\033[1m"
blue="\e[0;34m\033[1m"
yellow="\e[0;33m\033[1m"
purple="\e[0;35m\033[1m"
turquoise="\e[0;36m\033[1m"
gray="\e[0;37m\033[1m"

trap ctrl_c INT

function ctrl_c(){
	echo -e "\n\n${yellow}[*]${gray}Saliendo${end}"
	exit 0
}

function posts(){
if [ "$(id -u)" == 0 ]; then
	dependencies
	path=/var/www/html/wordpress
	if [ "$(echo $post)" == crear ]; then
		echo -e "${yellow}[*] Título del post:${blue}"
		read -p "[#] " -r titulo
		echo -e "${yellow}[*] Contenido del post:${blue}"
		read -p "[#] " -r contenido
		echo -e "${yellow}[*] Puedes incluir cualquiera de estos parámetros adicionales separándolos por espacios"
		echo -e "${purple}--post_author"
		echo "--post_date\tFormato: yyyy-mm-dd-hh-ii-ss"
		echo "--post_parent"
		echo "--post_name"
		echo "--post_id"
		echo "--post_type (Las opciones son: post, page, attachment, revision, nav_menu_item)"
		echo "Ejemplo: --post_name=codigosJava --post_parent=codigos --post_type=page --post_date=1995-06-21"
		echo -e "${end}${yellow}[*] ¿Quieres incluir alguna?${end}\t(Si la respuesta es no, sólo pulsa Enter)"
		read -p "[#] " -r parametros
		wp post create --post_title=$titulo --post_status=publish --post_content=$contenido $parametros --path=$path --allow-root
	elif [ "$(echo $post)" == lista ]; then
		wp post list --path=$path --allow-root
	elif [ "$(echo $post)" == editar ]; then
		wp post list --path=$path --allow-root --fields=ID,post_title
		echo -e "${yellow}[*] Escribe el id del post que quieres editar:"
		read -p "[#] " -r pos
		wp post edit $pos --path=$path --allow-root
	elif [ "$(echo $post)" == actualizar ]; then
		wp post list --path=$path --allow-root --fields=ID,post_title
		echo -e "${yellow}[*] Escribe el id del post que quieres actualizar:"
        read -p "[#] " -r pos
		echo -e "${yellow}[*] Escribe los parámetros que quieres actualizar separándolos por espacios"
		echo -e "${purple}--post_author"
        echo -e "--post_date\tFormato: yyyy-mm-dd-hh-ii-ss"
        echo "--post_parent"
        echo "--post_name"
        echo "--post_id"
		echo "--post_password"
		echo "--comment_status\t open/closed"
		echo "--post_id"
        echo "--post_type (Las opciones son: post, page, attachment, revision, nav_menu_item)"
        echo "Ejemplo: --post_name=codigosJava --post_parent=codigos --post_type=page --post_date=1995-06-21"
        wp post update $pos --path=$path --force --allow-root
	elif [ "$(echo $post)" == borrar ]; then
		wp post list --path=$path --allow-root --fields=ID,post_title
		echo -e "${yellow}[*] Escribe el id del post que quieres borrar:"
		read -p "[#] " -r pos
		wp post delete $pos --path=$path --force --allow-root
	elif [ "$(echo $post)" == borrarVarios ]; then
        	wp post list --path=$path --allow-root --fields=ID,post_title
        	echo -e "${yellow}[*] Escribe los id de los posts que quieres borrar separados por comas y sin espacios:"
	        read -p "[#] " -r pos
		IFS=',' read -a array <<< "$pos"
		for element in "${array[@]}"; do
	        	wp post delete $element --path=$path --force --allow-root
		done
	elif [ "$(echo $post)" == detalles ]; then
		wp post list --path=$path --allow-root --fields=ID,post_title
		echo -e "${yellow}[*] Escribe el id del post del que quieres ver detalles:"
		read -p "[#] " -r pos
		wp post get $pos --path=$path --allow-root
	elif [ "$(echo $post)" == crearVarios ]; then
		echo -e "${yellow}[*] Cuántos post quieres generar?:${blue}"
        read -p "[#] " -r numero
        echo -e "${yellow}[*] Título de los posts:${blue}"
        read -p "[#] " -r titulo
        echo -e "${yellow}[*] Puedes incluir cualquiera de estos parámetros adicionales separándolos por espacios"
        echo -e "${purple}--post_author"
        echo "--post_date\tFormato: yyyy-mm-dd-hh"
        echo "--post_type (Las opciones son: post, page, attachment, revision, nav_menu_item)"
        echo "Ejemplo: --post_author=SamSepiol --post_type=page --post_date=1995-06-21"
        echo -e "${end}${yellow}[*] ¿Quieres incluir alguna?${end}\t(Si la respuesta es no, sólo pulsa Enter)"
        read -p "[#] " -r parametros
        wp post generate --count=$numero --post_title=$titulo --path=$path --allow-root $parametros
	else
		echo -e "\n\t${red}P)${yellow} POSTS${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -P crear${end}"
		    echo -e "\n\t\t${turquoise}crear${end}\t\t${green}Crea un post${end}"
		    echo -e "\t\t${turquoise}editar${end}\t\t${green}Edita un post${end}"
		    echo -e "\t\t${turquoise}borrar${end}\t\t${green}Borra un post${end}"
		    echo -e "\t\t${turquoise}detalles${end}\t${green}Muestra detalles sobre un post${end}"
		    echo -e "\t\t${turquoise}crearVarios${end}\t${green}Crea más de un post a la vez${end}"
		    echo -e "\t\t${turquoise}borrarVarios${end}\t${green}Borra varios post a la vez${end}"
		    echo -e "\t\t${turquoise}lista${end}\t\t${green}Devuelve una lista de posts (sólo de posts, no incluye las páginas u otro tipo de posts)${end}"
	fi
else
	echo -e "${red}[X]${yellow} Debes acceder como root${end}"
fi
}

function idiomas(){
if [ "$(id -u)" == 0 ]; then
	dependencies
	path=/var/www/html/wordpress
	if [ "$(echo $idioma)" == instalar ]; then
		echo -e "Debes indicarlo en formato simplificado. Ejemplo: es (español), de (deutch), en (english)"
                echo -e "Si quieres que el idioma se active después de descargarlo escribe ${red}--activate${end}"
		echo -e "${yellow}[*] Cuál es el idioma que quieres instalar?"
		echo -e "${purple}Ejemplo: ${red}es --activate${blue}"
		read -p "[#] " -r idi
		echo -e "${end}"
		wp language core install $idi --path=$path --allow-root
	elif [ "$(echo $idioma)" == desinstalar ]; then
		wp language core list --status=installed --allow-root --path=$path
		echo -e "${yellow}[*] Cuál es el idioma que quieres desinstalar?${blue}"
                read -p "[#] " -r idi
                echo -e "${end}"
                wp language core uninstall $idi --path=$path --allow-root
	elif [ "$(echo $idioma)" == todos ]; then
		wp language core list --path=$path --allow-root
	elif [ "$(echo $idioma)" == instalados ]; then
		wp language core list --status=installed --allow-root --path=$path
	elif [ "$(echo $idioma)" == activar ]; then
		wp language core list --status=installed --allow-root --path=$path
                echo -e "${yellow}[*] Cuál es el idioma que quieres activar?${blue}"
                read -p "[#] " -r idi
                echo -e "${end}"
                wp language core activate $idi --path=$path --allow-root
	else
		echo -e "\n\t${red}l)${yellow} CAMBIAR IDIOMA DEL PANEL DE CONTROL DE WORDPRESS${end} ${red}[R]${end}\t${purple}Ejemplo: sudo ./script-wp.sh -l instalar${end}"
		    echo -e "\t\t${turquoise}instalar${end}\t${green}Instalar un idioma${end}"
		    echo -e "\t\t${turquoise}desinstalar${end}\t${green}Desinstala un idioma${end}"
		    echo -e "\t\t${turquoise}activar${end}\t\t${green}Activa un idioma ya descargado${end}"
		    echo -e "\t\t${turquoise}instalados${end}\t${green}Muestra una lista de los idiomas instalados${end}"
		        echo -e "\t\t${turquoise}todos${end}\t\t${green}Muestra una lista de todos los idiomas${end}"
	fi
else
	echo -e "${red}[X]${yellow} Debes acceder como root${end}"
fi
}

function temas(){
if [ "$(id -u)" == 0 ]; then
	dependencies
	path=/var/www/html/wordpress
	if [ "$(echo $tema)" == "instalar" ]; then
		clear; echo -e "\n${red}IMPORTANTE${yellow} El nombre del tema que debes escribir es el que aparece en la url de la página oficial de wordpress"
                echo -e "${blue}EJEMPLO: ${gray}https://wordpress.org/themes/${red}astra${end}"
                echo -e "${yellow}También puedes responder con la ruta o url del archivo .zip del tema"
                echo -e "\n${blue}[*]${yellow} Indica el nombre del tema que deseas instalar: ${blue}"
                read -p "[#] " -r tem
                wp theme install $tem --path=$path --allow-root
	elif [ "$(echo $tema)" == "desinstalar" ]; then
                clear; wp theme list --path=$path --allow-root
                echo -e "\n${yellow}Cual es el nombre del tema que quieres desinstalar? ${blue}"
		read -p "[#] " -r tem
                echo -e "\n${end}"
                wp theme delete $tem --path=$path --allow-root
	elif [ "$(echo $tema)" == "activar" ]; then
                clear; wp theme list --path=$path --allow-root
                echo -e "\n${yellow}Cual es el nombre del tema que quieres activar?${blue}"
		read -p "[#] " -r tem
                echo -e "\n${end}"
                wp theme activate $tem --path=$path --allow-root
	elif [ "$(echo $tema)" == "lista" ]; then
                wp theme list --path=$path --allow-root
	elif [ "$(echo $tema)" == "detalles" ]; then
                clear; wp theme list --path=$path --allow-root
                echo -e "\n${yellow}Cual es el nombre del tema del que quieres detalles??${blue}"
		read -p "[#] " -r tem
                echo -e "\n${end}"
                wp theme get --format=table $tem --path=$path --allow-root
	elif [ "$(echo $tema)" == "buscar" ]; then
                echo -e "\n${yellow}¿Qué estás buscando?${blue}"
		read -p "[#] " -r tem
                echo -e "\n${end}"
                wp theme search $tem --path=$path --allow-root --per-page=15 --fields=name,slug,rating,num_ratings
                echo -e "${turquoise}Si quieres ver la segunda página escribe${red} --page=2 ${turquoise}después de la búsqueda${end}\n${purple}Ejemplo: astra --page=2${end}"
	else
		echo -e "\n\t${red}t)${yellow} TEMAS${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -t instalar${end}"
		    echo -e "\n\t\t${turquoise}instalar${end}\t\t${green}Descargar un tema para wordpress${end}"
		    echo -e "\t\t${turquoise}desinstalar${end}\t\t${green}Desinstalar un tema${end}"
		    echo -e "\t\t${turquoise}activar${end}\t\t\t${green}Activar un tema${end}"
		    echo -e "\t\t${turquoise}lista${end}\t\t\t${green}Devuelve la lista con todos los temas descargados${end}"
		    echo -e "\t\t${turquoise}detalles${end}\t\t${green}Muestra los detalles de un tema${end}"
		    echo -e "\t\t${turquoise}buscar${end}\t\t\t${green}Muestra una tabla con los resultados de la búsqueda${end}"
	fi
else
	echo -e "${red}[X]${yellow} Debes iniciar como root.${end}"
fi
}

function plugins(){
if [ "$(id -u)" == 0 ]; then
	dependencies
	path=/var/www/html/wordpress
 	if [ "$(echo $plugin)" == "instalar" ]; then
		clear; echo -e "\n${red}IMPORTANTE${yellow} El nombre del plugin que debes escribir es el que aparece en la url de la página oficial de wordpress"
		echo -e "${blue}EJEMPLO: ${gray}https://wordpress.org/plugins/${red}wordpress-seo${end}"
		echo -e "${yellow}También puedes responder con la ruta o url del archivo .zip del plugin"
		echo -e "\n${blue}[*]${yellow} Indica el nombre del plugin que deseas instalar: ${blue}"
		read -p "[#] " -r plug
		wp plugin install $plug --path=$path --allow-root
	elif [ "$(echo $plugin)" == "desinstalar" ]; then
		clear; wp plugin list --path=$path --allow-root
		echo -e "\n${yellow}Cual es el nombre del plugin que quieres desinstalar? ${blue}"
		read -p "[#] " -r plug
		echo -e "\n${end}"
		wp plugin uninstall $plug --deactivate --path=$path --allow-root
	elif [ "$(echo $plugin)" == "lista" ]; then
                wp plugin list --path=$path --allow-root
	elif [ "$(echo $plugin)" == "activar" ]; then
		clear; wp plugin list --path=$path --allow-root
                echo -e "\n${yellow}Cual es el nombre del plugin que quieres activar?${blue}"
		echo -e "(Si escribes ${red}--all${end} se activarán todos)${blue}"
		read -p "[#] " -r plug
                echo -e "\n${end}"
                wp plugin activate $plug --path=$path --allow-root
	elif [ "$(echo $plugin)" == "desactivar" ]; then
		clear; wp plugin list --path=$path --allow-root
                echo -e "\n${yellow}Cual es el nombre del plugin que quieres desactivar?${blue}"
                echo -e "(Si escribes ${red}--all${end} se desactivarán todos)"
		echo -e "(Si escribes el nombre del plugin y seguido de un espacio ${red}--uninstall${end}, se desinstalará después de desactivarse)${blue}"
                read -p "[#] " -r plug
                echo -e "\n${end}"
                wp plugin deactivate $plug --path=$path --allow-root
	elif [ "$(echo $plugin)" == "activados" ]; then
		wp plugin list --status=active --path=$path --allow-root
	elif [ "$(echo $plugin)" == "desactivados" ]; then
		wp plugin list --status=inactive --path=$path --allow-root
	elif [ "$(echo $plugin)" == "detalles" ]; then
		clear; wp plugin list --path=$path --allow-root
                echo -e "\n${yellow}Cual es el nombre del plugin del que quieres detalles??${blue}"
                read -p "[#] " -r plug
                echo -e "\n${end}"
                wp plugin get --format=table $plug --path=$path --allow-root
	elif [ "$(echo $plugin)" == "buscar" ]; then
		echo -e "\n${yellow}¿Qué estás buscando?${blue}"
                read -p "[#] " -r plug
                echo -e "\n${end}"
                wp plugin search $plug --path=$path --allow-root --per-page=15 --fields=name,slug,rating,num_ratings
		echo -e "${turquoise}Si quieres ver la segunda página escribe${red} --page=2 ${turquoise}después de la búsqueda${end}\n${purple}Ejemplo: seo --page=5${end}"
	else
		echo -e "\n\t${red}p)${yellow} PLUGINS${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -p instalar${end}"
		    echo -e "\n\t\t${turquoise}instalar${end}\t\t${green}Descargar un plugin para wordpress${end}"
		    echo -e "\t\t${turquoise}desinstalar${end}\t\t${green}Desinstalar el plugin${end}"
		    echo -e "\t\t${turquoise}activar${end}\t\t\t${green}Activar un plugin${end}"
		    echo -e "\t\t${turquoise}desactivar${end}\t\t${green}Desactivar un plugin${end}"
		    echo -e "\t\t${turquoise}lista${end}\t\t\t${green}Devuelve la lista de todos los plugins descargados, instalados o no${end}"
		    echo -e "\t\t${turquoise}activados${end}\t\t${green}Devuelve una lista de los plugins activados${end}"
		    echo -e "\t\t${turquoise}desactivados${end}\t\t${green}Devuelve una lista de los plugins desactivados${end}"
		    echo -e "\t\t${turquoise}detalles${end}\t\t${green}Muestra los detalles de un plugin en concreto${end}"
		    echo -e "\t\t${turquoise}buscar${end}\t\t\t${green}Muestra una tabla con los resultados de la búsqueda${end}"
	fi
else
	echo -e "${red}[X]${yellow} Debes iniciar como root.${end}"
fi
}

function start(){
	if [ "$(id -u)" == 0 ]; then
		dependencies
		if [ "$(echo $instalation)" == "full" ]; then
			#COMPRUEBA SI WP-CLI EXISTE Y SI NO EXISTE LO INSTALA
			if [ -f /usr/local/bin/wp ]; then
				echo -e "${green}[V]${turquoise}TIENES EL WP-CLI${end}"
				wpInstalation
			else
				echo -e "\n${red}[X] NO TIENES WP-CLI${end}"
				sleep 0.5
				echo -e "\n${yellow}[*]${yellow} DESCARGANDO WP-CLI...${end}"
				sleep 0.5
				curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar 2>/dev/null
				sudo chmod +x wp-cli.phar 2>/dev/null
				sudo mv wp-cli.phar /usr/local/bin/wp
				echo -e "\n${blue}[*]${green} WP-CLI DESCARGADO CORRECTAMENTE Y UBICADO EN /usr/local/bin/wp${end}"
				sleep 0.5
				wpInstalation
			fi
		elif [ "$(echo $instalation)" == "wp-cli" ]; then
		   if [ -f /usr/local/bin/wp ]; then
			echo -e "${red}[*]${yellow} YA TIENES WP-CLI DESCARGADO Y UBICADO EN /usr/local/bin/wp${end}"
		   else
			echo -e "\n${yellow}[*]${yellow} DESCARGANDO WP-CLI...${end}"
	                sleep 0.5
	                curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar 2>/dev/null
	                sudo chmod +x wp-cli.phar 2>/dev/null
			sudo mv wp-cli.phar /usr/local/bin/wp
	                echo -e "\n${blue}[*]${green} WP-CLI DESCARGADO CORRECTAMENTE Y UBICADO EN /usr/local/bin/wp${end}"
		   fi
		elif [ "$(echo $instalation)" == "wordpress" ]; then
			if [ -f /usr/local/bin/wp ]; then
				echo -e "${green}[V]${turquoise}TIENES EL WP-CLI${end}"
				wpInstalation
			else
				echo -e "${red}[X] NO TIENES WP-CLI DESCARGADO${end}"
				echo -e "Usa ${green}-i wp-cli${end} para descargarlo o ${blue}-i full${end} para hacerlo todo a la vez"
			fi
		else
			echo -e "\n\t${red}i)${yellow} MODO INSTALACIÓN${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -i full${end}"
			    echo -e "\n\t\t${turquoise}wp-cli${end}\t\t${green}Descargar wp-cli${end}"
			    echo -e "\t\t${turquoise}wordpress${end}\t${green}Instalar wordpress${end}"
			    echo -e "\t\t${turquoise}full${end}\t\t${green}Descargar wp-cli e instalar wordpress${end}"
		fi
	else
		echo -e "\n${yellow}[*]${red} Debes iniciar como root${end}"
	fi
}

function dependencies(){
	if [ -d /etc/apache2/ ]; then
		systemctl status apache2 1>/dev/null
		if [ "$(echo $?)" == 0 ];then
			echo -e "${green}[V] Apache${end}"
		else
			echo -e "${yellow}[*] Apache2 desactivado. Activando apache2....${end}"
			systemctl start apache2
		fi
	else
		echo -e "${red} [X] Apache2 no está instalado.${end}"
		echo -e "${yellow}[*] Instalando apache2..."
		sudo apt-get install apache2 2>/dev/null
		sudo systemctl start apache2
		echo -e "${green}[V] Apache2 instalado y activado!${end}"
	fi

	if [ -d /etc/mysql/ ]; then
		systemctl status mysql 1>/dev/null
		if [ "$(echo $?)" == 0 ];then
			echo -e "${green}[V] Mysql${end}"	
		else
			echo -e "${yellow}[*] Mysql desactivado. Activando mysql..."
			systemctl start mysql
		fi
	else
		echo -e "${red}[X] Mysql no está instalado."
		echo -e "${yellow} [*] Descargando y activando mysql...${end}"
		sudo apt-get install default-mysql-server 2>/dev/null
		systemctl start mysql
		echo -e "${green}[V] Mysql instalado y activado!"
	fi	
}

function wpInstalation(){
	if [ -d /var/www/html/wordpress/ ]; then
		echo -e "${yellow}[*]${turquoise} YA TIENES WORDPRESS INSTALADO EN /var/www/html"
		echo -e "${yellow}[*] CANCELANDO LA INSTALACIÓN...${end}"
		exit 0
	else
		clear
		echo -e "\n${yellow}[*]${yellow} DESCARGANDO WORDPRESS...${end}"
	        current="$(pwd)"
	      	mkdir /var/www/html/wordpress
	        cp wp-cli.phar /var/www/html/wordpress
	        cd /var/www/html/wordpress
	        wp core download --allow-root
	        echo -e "\n${blue}[*]${green} DIRECTORIO DE WORDPRESS CREADO EN /var/www${end}"
	        echo -e "\n${blue}[*]${green} Iniciando los servicios apache2 y mysql${end}"
		sudo systemctl start mysql 2>/dev/null
		sudo systemctl start apache2 2>/dev/null
		sleep 1
		echo -e "\n${purple}Nombre de la base de datos: ${red}"
		read -p "[#] " -r bbdd
		echo $bbdd > /var/www/html/wordpress/wp-data
		echo -e "\n${purple}Nombre de usuario: ${red}"
		read -p "[#] " -r usuario
		echo $usuario >> /var/www/html/wordpress/wp-data
		echo -e "${end}\n${purple}Contraseña: ${red}"
		read -p "[#] " -r -s pass
		echo -e "\n${end}"
		sudo mysql --user=root mysql -e "create user '$usuario'@'localhost' identified by '$pass';"
		sudo mysql --user=root mysql -e "grant all privileges on *.* to '$usuario'@'localhost' with grant option;"
		sudo mysql --user=root mysql -e "flush privileges"
	        wp config create --dbname=$bbdd --dbuser=$usuario --dbpass=$pass --allow-root
		echo -e "\n${gree}[V]${blue} ARCHIVO WP-CONFIG CREADO ${end}"
		sudo wp db create --allow-root
		echo -e "\n${gree}[V]${blue} BASE DE DATOS CREADA${end}"
		echo -e "\n${yellow}Añade un title para el sitio: "
		read -p "[#] " -r titulo
		echo -e "${end}"
		wp core install --url=localhost/wordpress --title=$titulo --admin_user=$usuario --admin_password=$pass --admin_email=ejemplo@ejemplo.com --allow-root
		if [ "$(echo $?)" == 0 ]; then
			echo -e "\n${green}[V]${blue} INSTALACIÓN REALIZADA CORRECTAMENTE${end}"
			echo -e "${red}IMPORTANTE: ${green}La contraseña establecida es para el usuario 'root'${end}"
		else
			echo -e "\n${red}[X]${yellow} HA HABIDO UN PROBLEMA${end}"
		fi
	        cd $current
	fi
}

function helpPanel(){
	echo -e "\n${yellow}[*]${gray} USO: ./script-wp.sh${end}"
    echo -e "${red}[R]${end} = REQUIERE ROOT"   
    echo -e "Usuario -> $(awk 'NR==26' /var/www/html/wordpress/wp-config.php | sed -e "s/define( 'DB_USER', '//g" -e "s/' );//g")"
	echo -e "\n\t${red}H)${yellow} VER PANEL DE AYUDA VERSIÓN COMPLETA ${red}[R]\t${purple}Ejemplo: ./script-wp.sh -H${end}"
	echo -e "\n\t${red}i)${yellow} MODO INSTALACIÓN ${red}[R]\t${purple}Ejemplo: ./script-wp.sh -i full${end}"
	echo -e "\n\t${red}p)${yellow} PLUGINS ${red}[R]\t${purple}Ejemplo: ./script-wp.sh -p instalar${end}"
	echo -e "\n\t${red}t)${yellow} TEMAS ${red}[R]\t${purple}Ejemplo: ./script-wp.sh -t instalar${end}"
	echo -e "\n\t${red}P)${yellow} POSTS ${red}[R]\t${purple}Ejemplo: ./script-wp.sh -P crear${end}"
	echo -e "\n\t${red}a)${yellow} ABRIR WORDPRESS EN EL NAVEGADOR${end}"
	echo -e "\n\t${red}b)${yellow} MODO BORRADO${end} ${red}[R]${end}"
    echo -e "\n\t${red}h)${yellow} PANEL DE AYUDA${end}"
    echo -e "\n\t${red}l)${yellow} CAMBIAR IDIOMA DEL PANEL DE CONTROL DE WORDPRESS${end} ${red}[R]${end}\t${purple}Ejemplo: sudo ./script-wp.sh -l instalar${end}"
	echo -e "\n\t${red}s)${yellow} ACTIVAR/DESACTIVAR MODO SEO${end} ${red}[R]${end}"
	if [ -f /var/www/html/wordpress/seo ]; then
        echo -e "\t\t${green}[A] Modo seo activado${end}"
    else
        echo -e "\t\t${red}[D] Modo seo desactivado${end}"
    fi
}

function fullHelpPanel(){
	echo -e "\n${yellow}[*]${gray} USO: ./script-wp.sh${end}"
	echo -e "${red}[R]${end} = REQUIERE ROOT"	
	echo -e "Usuario -> $(awk 'NR==26' /var/www/html/wordpress/wp-config.php | sed -e "s/define( 'DB_USER', '//g" -e "s/' );//g")"

	echo -e "\n\t${red}i)${yellow} MODO INSTALACIÓN${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -i full${end}"
	echo -e "\n\t\t${turquoise}wp-cli${end}\t\t${green}Descargar wp-cli${end}"
	echo -e "\t\t${turquoise}wordpress${end}\t${green}Instalar wordpress${end}"
	echo -e "\t\t${turquoise}full${end}\t\t${green}Descargar wp-cli e instalar wordpress${end}"

	echo -e "\n\t${red}p)${yellow} PLUGINS${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -p instalar${end}"
   	echo -e "\n\t\t${turquoise}instalar${end}\t\t${green}Descargar un plugin para wordpress${end}"
   	echo -e "\t\t${turquoise}desinstalar${end}\t\t${green}Desinstalar el plugin${end}"
   	echo -e "\t\t${turquoise}activar${end}\t\t\t${green}Activar un plugin${end}"
 	echo -e "\t\t${turquoise}desactivar${end}\t\t${green}Desactivar un plugin${end}"
 	echo -e "\t\t${turquoise}lista${end}\t\t\t${green}Devuelve la lista de todos los plugins descargados, instalados o no${end}"
	echo -e "\t\t${turquoise}activados${end}\t\t${green}Devuelve una lista de los plugins activados${end}"
	echo -e "\t\t${turquoise}desactivados${end}\t\t${green}Devuelve una lista de los plugins desactivados${end}"
	echo -e "\t\t${turquoise}detalles${end}\t\t${green}Muestra los detalles de un plugin en concreto${end}"
	echo -e "\t\t${turquoise}buscar${end}\t\t\t${green}Muestra una tabla con los resultados de la búsqueda${end}"

	echo -e "\n\t${red}t)${yellow} TEMAS${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -t instalar${end}"
    echo -e "\n\t\t${turquoise}instalar${end}\t\t${green}Descargar un tema para wordpress${end}"
   	echo -e "\t\t${turquoise}desinstalar${end}\t\t${green}Desinstalar un tema${end}"
   	echo -e "\t\t${turquoise}activar${end}\t\t\t${green}Activar un tema${end}"
   	echo -e "\t\t${turquoise}lista${end}\t\t\t${green}Devuelve la lista con todos los temas descargados${end}"
   	echo -e "\t\t${turquoise}detalles${end}\t\t${green}Muestra los detalles de un tema${end}"
	echo -e "\t\t${turquoise}buscar${end}\t\t\t${green}Muestra una tabla con los resultados de la búsqueda${end}"

	echo -e "\n\t${red}P)${yellow} POSTS${end} ${red}[R]${end}\t${purple}Ejemplo: ./script-wp.sh -P crear${end}"
    echo -e "\n\t\t${turquoise}crear${end}\t\t${green}Crea un post${end}"
    echo -e "\t\t${turquoise}editar${end}\t\t${green}Edita un post${end}"
    echo -e "\t\t${turquoise}borrar${end}\t\t${green}Borra un post${end}"
    echo -e "\t\t${turquoise}detalles${end}\t${green}Muestra detalles sobre un post${end}"
    echo -e "\t\t${turquoise}crearVarios${end}\t${green}Crea más de un post a la vez${end}"
    echo -e "\t\t${turquoise}borrarVarios${end}\t${green}Borra varios post a la vez${end}"
    echo -e "\t\t${turquoise}lista${end}\t\t${green}Devuelve una lista de posts (sólo de posts, no incluye las páginas u otro tipo de posts)${end}"

	echo -e "\n\t${red}a)${yellow} ABRIR WORDPRESS EN EL NAVEGADOR${end}"
	echo -e "\t\t${turquoise}home${end}\t\t${green}Abre la página principal (localhost/wordpress)${end}"
	echo -e "\t\t${turquoise}admin${end}\t\t${green}Abre el panel de control de wordpress (localhost/wordpress/wp-admin)${end}"
	echo -e "\t\t${turquoise}post${end}\t\t${green}Abre un post (localhost/wordpress/post)${end}"

	echo -e "\n\t${red}b)${yellow} MODO BORRADO${end} ${red}[R]${end}"
	echo -e "\n\t${red}l)${yellow} CAMBIAR IDIOMA DEL PANEL DE CONTROL DE WORDPRESS${end} ${red}[R]${end}\t${purple}Ejemplo: sudo ./script-wp.sh -l instalar${end}"
	echo -e "\t\t${turquoise}instalar${end}\t${green}Instalar un idioma${end}"
	echo -e "\t\t${turquoise}desinstalar${end}\t${green}Desinstala un idioma${end}"
	echo -e "\t\t${turquoise}activar${end}\t\t${green}Activa un idioma ya descargado${end}"
	echo -e "\t\t${turquoise}instalados${end}\t${green}Muestra una lista de los idiomas instalados${end}"
    	echo -e "\t\t${turquoise}todos${end}\t\t${green}Muestra una lista de todos los idiomas${end}"

	echo -e "\n\t${red}h)${yellow} PANEL DE AYUDA SIMPLE${end}"
	echo -e "\n\t${red}H)${yellow} PANEL DE AYUDA DETALLADO${end}"

    	echo -e "\n\t${red}s)${yellow} ACTIVAR/DESACTIVAR MODO SEO${end} ${red}[R]${end}"
	echo -e "\t\t${blue}Cuando el modo seo se activa se instala el tema Astra y el plugin Yoast Seo\n\t\tlos cuales se encargarán de ayudarte a optimizar la web.${end}"
	if [ -f /var/www/html/wordpress/seo ]; then
		echo -e "\t\t${green}[A] Modo seo activado${end}"
	else
		echo -e "\t\t${red}[D] Modo seo desactivado${end}"
	fi
}

function borradoCompleto(){
	dependencies
	if [ "$(id -u)" == "0" ]; then
		echo -e "\n${red}[*]${red} REALIZANDO BORRADO COMPLETO...${end}"
		base="$(awk 'NR == 1' /var/www/html/wordpress/wp-data)"
                user="$(awk 'NR == 2' /var/www/html/wordpress/wp-data)"
                sudo mysql --user=root mysql -e "drop database $base ;"
                sudo mysql --user=root mysql -e "delete user from mysql.user where user = '$user' ;"
		sudo rm -r /var/www/html/wordpress
		sudo rm /usr/local/bin/wp
		echo -e "\n${blue}[*]${green} BORRADO REALIZADO CORRECTAMENTE${end}"
	else
		echo -e "\n${yellow}[*]${red} Debes iniciar como root${end}"
	fi
}

function abrir(){
	dependencies
	if [ "$(id -u)" == 0 ]; then
		echo -e "${red}[*] Este comando debe ejecutarse sin permisos root${end}"
	else
		if [ "$(echo $abrirOption)" == "home" ]; then
			echo -e "${blue}[*]${yellow} ABRIENDO localhost/wordpress EN EL NAVEGADOR...${end}"
			firefox http://localhost:80/wordpress 2>/dev/null
			disown
		elif [ "$(echo $abrirOption)" == "admin" ]; then
			firefox http://localhost:80/wordpress/wp-admin 2>/dev/null
			disown
		elif [ "$(echo $abrirOption)" == "post" ]; then
			wp post list --path=/var/www/html/wordpress --allow-root
			echo -e "${yellow}[*] Escribe el nombre del post que quieres abrir: "
			read -p "[#] " -r pag
	                firefox http://localhost:80/wordpress/index.php/$pag 2>/dev/null
			disown
		else
			echo -e "\n\t${red}a)${yellow} ABRIR WORDPRESS EN EL NAVEGADOR${end}"
		    echo -e "\t\t${turquoise}home${end}\t\t${green}Abre la página principal (localhost/wordpress)${end}"
	    	echo -e "\t\t${turquoise}admin${end}\t\t${green}Abre el panel de control de wordpress (localhost/wordpress/wp-admin)${end}"
			echo -e "\t\t${turquoise}post${end}\t\t${green}Abre un post (localhost/wordpress/post)${end}"
		fi
	fi
}

function modoSeo(){
	if [ "$(id -u)" == 0 ]; then
		if [ -f /var/www/html/wordpress/seo ]; then
			echo -e "Desactivando modo seo..."
			sudo rm /var/www/html/wordpress/seo
			wp theme install twentytwenty --path=/var/www/html/wordpress --allow-root 2>/dev/null
                	wp theme activate twentytwenty --path=/var/www/html/wordpress --allow-root 2>/dev/null
                	wp theme delete astra --path=/var/www/html/wordpress --allow-root
			wp plugin uninstall wordpress-seo --deactivate --path=/var/www/html/wordpress --allow-root
			echo -e "${red}[V] MODO SEO DESACTIVADO${end}"
		else
			echo "Activando modo seo..."
			echo "activado" > /var/www/html/wordpress/seo
			echo -e "${yellow}[*] Descargando y activando Astra${end}\n"
			wp theme install astra --path=/var/www/html/wordpress --allow-root 2>/dev/null
                	wp theme activate astra --path=/var/www/html/wordpress --allow-root 2>/dev/null
			echo -e "${yellow}[*] Descargando y activando Yoast Seo${end}\n"
			wp plugin install wordpress-seo --path=/var/www/html/wordpress --allow-root 2>/dev/null 
			wp plugin activate wordpress-seo --path=/var/www/html/wordpress --allow-root 2>/dev/null
			echo -e "${green}[V] MODO SEO ACTIVADO${end}"	
		fi
	else
		echo -e "\n${yellow}[*]${red} Debes iniciar como root${end}"
	fi
}

declare -i counter=0;while getopts "i:p:P:a:t:l:bshH" arg; do
		case $arg in
			i) instalation=$OPTARG; start; counter+=1;;
			b) borradoCompleto; counter+=1;;
			P) post=$OPTARG; posts; counter+=1;;
			a) abrirOption=$OPTARG; abrir; counter+=1;;
			l) idioma=$OPTARG; idiomas; counter+=1;;
			t) tema=$OPTARG; temas; counter+=1;;
			s) modoSeo; counter+=1;;
			p) plugin=$OPTARG; plugins; counter+=1;;
			h) helpPanel; counter+=1;;
			H) fullHelpPanel; counter+=1;;
		esac
	if [ $counter == 0 ];then
		fullHelpPanel
	else
		tput cnorm
	fi
done
